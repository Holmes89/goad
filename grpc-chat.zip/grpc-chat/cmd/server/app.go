package main

import (
	"google.golang.org/grpc"
	"github.com/sirupsen/logrus"
	"grpc-chat/internal/message"
	"io"
	"log"
	"net"
)

func main() {

	messageServer := NewServer()
	lis, err := net.Listen("tcp", ":8081")
	if err != nil {
		logrus.Fatal("Failed to listen: ", err.Error())
	}

	grpcServer := grpc.NewServer()

	message.RegisterMessengerServer(grpcServer, messageServer)

	if err := grpcServer.Serve(lis); err != nil {
		log.Panic("failed to serve: ", err.Error())
	}
}


func NewServer() message.MessengerServer {

	mc := make(chan *message.Message)

	s := &server{
		messageChan: mc,
	}

	go func(messages chan *message.Message) {
		for m := range messages {
			logrus.WithFields(
				logrus.Fields{
					"from": m.From,
					"room": m.Room,
					"message": m.Body,
					"uuid": m.Uuid,
				}).Info("recieved message")
			for idx, msgr := range s.streams {
				logrus.WithField("idx", idx).Info("sending to stream")
				go func(sender message.Messenger_SendMessageServer) {
					sender.Send(m)
				}(*msgr)
			}
		}
	}(mc)

	return s
}

type server struct {
	streams []*message.Messenger_SendMessageServer
	messageChan chan *message.Message
}

func (s *server) AddStream(messenger *message.Messenger_SendMessageServer) {
	s.streams = append(s.streams, messenger)
	logrus.WithField("connections", len(s.streams)).Info("added stream")
}

//TODO Remove exited streams
func (s *server) RemoveStream(messenger message.Messenger_SendMessageServer) {
	s.streams = append(s.streams, &messenger)
}

func (s *server) SendMessage(messenger message.Messenger_SendMessageServer) error {
	s.AddStream(&messenger)
	for {
		resp, err := messenger.Recv()
		if err == io.EOF {
			break
		}
		if err != nil {
			logrus.WithField("error", err.Error()).Error("received error")
			break
		}


		s.messageChan <- &message.Message{
			From: resp.From,
			Body: resp.Body,
		}
	}
	return nil
}